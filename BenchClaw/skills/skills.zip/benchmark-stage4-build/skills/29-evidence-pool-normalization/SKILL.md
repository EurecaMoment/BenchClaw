# Skill 29 — 证据池规范化

全局路径约束：`BENCHCLAW_ROOT` 仅作只读输入；`WORKSPACE_ROOT` 是本次流程唯一总工作目录，所有写操作和流程产物只能落在其下。

## 父节点

`18`, `19`, `20`

## 任务

把三条 Stage3 数据分支合并为 typed evidence pool，但必须保留来源：

- `source_branch = real_image | existing_benchmark | simulator`；
- `gt_source_type = simulator_privileged_gt | official_label | tool_generated_candidate | derived_geometry`；
- media path、GT 字段、置信度、工具版本、清洗日志、失败原因。

输出不是最终题目，只是可供模板绑定的证据索引。

## 输出

```text
WORKSPACE_ROOT/stage4/<node>/manifest.jsonl
WORKSPACE_ROOT/stage4/29-evidence-pool-normalization/evidence_pool.jsonl
WORKSPACE_ROOT/stage4/29-evidence-pool-normalization/evidence_manifest.json
WORKSPACE_ROOT/stage4/29-evidence-pool-normalization/source_balance_report.md
USED_INPUTS.json
DONE.json
```

规范真相源应写入 `evidence_pool.jsonl`；`evidence_pool.jsonl` 仅作为兼容性导出。


---

## I/O 合同摘要

```text
node_id: 29
parents: ['18', '19', '20']
output_dir: WORKSPACE_ROOT/stage4/29-evidence-pool-normalization
```

完整白名单以 `contracts/node_io_contracts.json` 为准。
